package bengen.bean;

import java.util.List;
import lombok.Getter;
import lombok.Setter;
import bengen.bean.*;


@Getter
@Setter
public class CourseListDto {
    private Enumstatus status;
    private float price;
    private String title;
    private String cover;
    private String poster;

}